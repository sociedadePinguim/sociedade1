#!/bin/bash
sudo rm /var/lib/dpkg/lock-frontend; sudo rm /var/cache/apt/archives/lock ;
echo "visite o nosso site http://sociedade-pinguim.rf.gd"
echo " deseja instalar o $0. ?"
echo
	read -p "Press [Enter]"


sudo rm -Rf /opt/popcorntime

sudo rm -Rf /usr/bin/Popcorn-Time

sudo rm -Rf /usr/share/applications/popcorntime.desktop

wget https://get.popcorntime.sh/build/Popcorn-Time-0.3.10-Linux-64.tar.xz -O popcorntime.tar.xz

sudo mkdir /opt/popcorntime

sudo tar Jxf popcorntime.tar.xz -C /opt/popcorntime/

sudo ln -sf /opt/popcorntime/Popcorn-Time /usr/bin/Popcorn-Time

echo -e '[Desktop Entry]\n Version=1.0\n Name=popcorntime\n Exec=/opt/popcorntime/Popcorn-Time\n Icon=/opt/popcorntime/src/app/images/icon.png\n Type=Application\n Categories=Application' | sudo tee /usr/share/applications/popcorntime.desktop

sudo chmod +x /usr/share/applications/popcorntime.desktop

cp /usr/share/applications/popcorntime.desktop  ~/Área\ de\ Trabalho/

cp /usr/share/applications/popcorntime.desktop ~/Desktop

