#!/bin/bash
sudo rm /var/lib/dpkg/lock-frontend; sudo rm /var/cache/apt/archives/lock ;
echo "visite o nosso site http://sociedade-pinguim.rf.gd"
echo " deseja instalar o $0. ?"
echo
	read -p "Press [Enter]"


sudo apt-get install preload 
sudo apt-get install prelink
sudo apt update && sudo apt dist-upgrade