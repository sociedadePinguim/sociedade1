#! /bin/bash
sudo rm /var/lib/dpkg/lock-frontend; sudo rm /var/cache/apt/archives/lock ;

echo " deseja instalar o $0. ?"
echo
	read -p "Press [Enter]"
sudo add-apt-repository ppa:paulo-miguel-dias/mesa -y
sudo apt full-upgrade
sudo rm /var/lib/dpkg/lock-frontend; sudo rm /var/cache/apt/archives/lock
sudo apt install mesa-vulkan-drivers mesa-vulkan-drivers:i386
sudo apt-get install libvulkan1 libvulkan1:i386
sudo apt install libgl1-mesa-glx:i386 libgl1-mesa-dri:i386
sudo apt update && sudo apt upgrade
sudo apt install mesa-vulkan-drivers vulkan-utils libassimp4
sudo apt update && sudo apt upgrade
sudo apt-add-repository 'deb https://dl.winehq.org/wine-builds/ubuntu/ bionic main'

sudo dpkg --add-architecture i386
sudo apt install wine-stable -y
sudo apt install libwine-development -y
sudo apt install wine64-development -y
sudo apt install fonts-wine -y
sudo apt install wine64 wine32-preloader winetricks -y
sudo apt install lutris libvulkan1 libvulkan1:i386 -y
sudo apt install mesa-vulkan-drivers mesa-vulkan-drivers:i386
echo Instalando o wine64 e x86

sudo apt update && sudo apt dist-upgrade
wget -nc https://dl.winehq.org/wine-builds/winehq.key
sudo apt-key add winehq.key
sudo apt-get install --install-recommends winehq-stable wine-stable wine-stable-i386 wine-stable-amd64 -y
sudo apt install --install-recommends winehq-staging -y
sudo apt install --install-recommends winehq-staging wine-staging wine-staging-i386 -y
sudo apt install libgnutls30:i386 libldap-2.4-2:i386 libgpg-error0:i386 libxml2:i386 libasound2-plugins:i386 libsdl2-2.0-0:i386 libfreetype6:i386 libdbus-1-3:i386 libsqlite3-0:i386 -y


sudo apt autoremove
sudo apt autoclean

sudo apt update && sudo apt dist-upgrade
sudo apt-get autoremove
echo "visite o nosso site http://sociedade-pinguim.rf.gd"

