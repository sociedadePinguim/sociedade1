#! /bin/bash
sudo rm /var/lib/dpkg/lock-frontend; sudo rm /var/cache/apt/archives/lock ;

echo " deseja instalar o $0. ?"
echo
	read -p "Press [Enter]"




sudo add-apt-repository ppa:obsproject/obs-studio && sudo apt-get update && sudo apt-get install obs-studio

sudo add-apt-repository ppa:kirillshkrogalev/ffmpeg-next && sudo apt-get update && sudo apt-get install ffmpeg
sudo add-apt-repository ppa:obsproject/obs-studio && sudo apt-get update && sudo apt-get install obs-studio
mkdir -p $HOME/.config/obs-studio/plugins
wget https://github.com/bazukas/obs-linuxbrowser/releases/download/0.2.0/linuxbrowser0.2.0-obs18.0.1-64bit.tgz
tar xfvz linuxbrowser0.2.0-obs18.0.1-64bit.tgz -C $HOME/.config/obs-studio/plugins
