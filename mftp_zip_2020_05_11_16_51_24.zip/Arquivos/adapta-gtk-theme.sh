sudo rm /var/lib/dpkg/lock-frontend; sudo rm /var/cache/apt/archives/lock ;

echo " deseja instalar o $0. ?"
echo
	read -p "Press [Enter]"
	sudo add-apt-repository ppa:tista/adapta -y
	sudo apt-get update
	sudo apt install adapta-gtk-theme -y

