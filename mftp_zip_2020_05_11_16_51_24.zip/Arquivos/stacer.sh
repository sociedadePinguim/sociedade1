#!/bin/bash
sudo rm /var/lib/dpkg/lock-frontend; sudo rm /var/cache/apt/archives/lock ;
echo "visite o nosso site http://sociedade-pinguim.rf.gd"
echo " deseja instalar o $0. ?"
echo
	read -p "Press [Enter]"


wget https://github.com/oguzhaninan/Stacer/releases/download/v1.0.9/stacer_1.0.9_amd64.deb -O stacer.deb
sudo dpkg -i stacer.deb
sudo apt-get install -f