#!/bin/bash
sudo rm /var/lib/dpkg/lock-frontend; sudo rm /var/cache/apt/archives/lock ;
echo "visite o nosso site http://sociedade-pinguim.rf.gd"
echo " deseja instalar o $0. ?"
echo
	read -p "Press [Enter]"

sudo rm /var/lib/dpkg/lock-frontend; sudo rm /var/cache/apt/archives/lock ;
echo terminal-do-XFCE

read -p "Press [Enter]"

sudo apt-get install xfce4-terminal